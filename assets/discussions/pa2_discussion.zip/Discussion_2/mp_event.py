import multiprocessing as mp
from multiprocessing import Process
import time

# --- color setup (modular & simple) ---
COLOR_RESET  = "\033[0m"
COLOR_YELLOW = "\033[93m"
COLOR_GREEN  = "\033[92m"

COLORS = {
    "Task A": COLOR_YELLOW,
    "Task B": COLOR_GREEN,
}

def log(task, message):
    color = COLORS.get(task, "")
    reset = COLOR_RESET if color else ""
    print(f"{color}[{task}] {message}{reset}")

def task_a(ctx, evt):
    log("Task A", "Enter Task A")
    time.sleep(1)
    ctx['a'] = 1
    log("Task A", "Set ctx['a']=1; signalling Task B")
    evt.set()
    log("Task A", "Exit Task A")

def task_b(ctx, evt):
    log("Task B", "Enter Task B; waiting for Task A…")
    evt.wait()
    log("Task B", f"Detected ctx: {ctx}")
    log("Task B", "Exit Task B")

if __name__ == "__main__":
    manager = mp.Manager()
    shared = manager.dict()
    evt = mp.Event()

    p1 = Process(target=task_a, args=(shared, evt))
    p2 = Process(target=task_b, args=(shared, evt))
    p1.start()
    p2.start()
    p1.join()
    p2.join()