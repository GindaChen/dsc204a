import multiprocessing as mp
from multiprocessing import Process

# --- color setup (modular & simple) ---
COLOR_RESET  = "\033[0m"
COLOR_YELLOW = "\033[93m"
COLOR_GREEN  = "\033[92m"

COLORS = {
    "Task A": COLOR_YELLOW,
    "Task B": COLOR_GREEN,
}

def log(task, message):
    color = COLORS.get(task, "")
    reset = COLOR_RESET if color else ""
    print(f"{color}[{task}] {message}{reset}")

def task_a(ctx, cond):
    with cond:
        log("Task A", "Enter Task A")
        ctx['a'] = 1
        log("Task A", "Set ctx['a']=1; notifying all")
        cond.notify_all()
        log("Task A", "Exit Task A")

def task_b(ctx, cond):
    with cond:
        log("Task B", "Enter Task B; waiting for predicate")
        cond.wait_for(lambda: 'a' in ctx)
        log("Task B", f"Detected ctx: {ctx}")
        log("Task B", "Exit Task B")

if __name__ == "__main__":
    manager = mp.Manager()
    shared = manager.dict()
    cond = mp.Condition()

    p1 = Process(target=task_a, args=(shared, cond))
    p2 = Process(target=task_b, args=(shared, cond))
    p1.start()
    p2.start()
    p1.join()
    p2.join()