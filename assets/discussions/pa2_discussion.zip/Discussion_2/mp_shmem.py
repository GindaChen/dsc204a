import multiprocessing as mp
from multiprocessing import Process
import time

# --- color setup (modular & stupidly simple) ---
COLOR_RESET  = "\033[0m"
COLOR_YELLOW = "\033[93m"
COLOR_GREEN  = "\033[92m"

COLORS = {
    "Task A": COLOR_YELLOW,
    "Task B": COLOR_GREEN,
}

def log(task, message):
    color = COLORS.get(task, "")
    reset = COLOR_RESET if color else ""
    print(f"{color}[{task}] {message}{reset}")

def task_a(ctx):
    log("Task A", "Enter Task A")
    log("Task A", f"Before waiting - shared_dict: {ctx}")
    time.sleep(1)
    ctx['a'] = 1
    log("Task A", f"After waiting - shared_dict: {ctx}")
    log("Task A", "Exit Task A")

def task_b(ctx):
    log("Task B", "Enter Task B")
    log("Task B", f"Before waiting - shared_dict: {ctx}")
    while 'a' not in ctx:
        time.sleep(0.01)
    log("Task B", f"After waiting - shared_dict: {ctx}")
    ctx['b'] = 2
    log("Task B", f"After updating - shared_dict: {ctx}")
    log("Task B", "Exit Task B")

if __name__ == "__main__":
    manager = mp.Manager()
    shared_dict = manager.dict()
    p1 = Process(target=task_a, args=(shared_dict,))
    p2 = Process(target=task_b, args=(shared_dict,))
    p1.start()
    p2.start()
    p1.join()
    p2.join()